import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MecanicosRoutingModule } from './mecanicos-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MecanicosRoutingModule
  ]
})
export class MecanicosModule { }
